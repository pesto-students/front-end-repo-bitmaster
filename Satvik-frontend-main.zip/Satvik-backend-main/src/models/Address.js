const mongoose = require('mongoose');

const AddressSchema = new mongoose.Schema({

    recieversName:{
        type:String,
        required:false,
    },
    recieversPhoneNo:{
        type:Number,
        required:false,
    },
    saveAs:{
        type:String,
        required:true,
        default:"Home"
    },
    houseNoAndFloor:{
        type:String,
        required:true,
    },
    area:{
        type:String,
        required:true,
    },
    landmark:{
        type:String,
        required:false,
    },
    AccountId: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'Account'
    },
},{
    timestamps: true
})

const Address = mongoose.model('Address',AddressSchema,'addresses');

module.exports = Address;