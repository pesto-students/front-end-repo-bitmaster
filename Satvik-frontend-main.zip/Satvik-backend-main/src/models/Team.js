const mongoose = require('mongoose');

const teamSchema = new mongoose.Schema({

    name:{
        type:String,
        required: true
    },
    about:{
        type:String,
        required: true
    },
    imgUrl:{
        type:String,
        required: true
    }

})

const team = mongoose.model('Team', teamSchema , "Team");

module.exports = team;