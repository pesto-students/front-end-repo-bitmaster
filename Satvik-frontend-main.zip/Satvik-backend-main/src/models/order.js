const mongoose = require('mongoose');
const discountAppliedDetailsSchema = require('./discountAppliedDetails');
const feedback = require('./feedback');
const orderAmountSchema = require('./OrderAmountDetails');

const orderSchema = new mongoose.Schema({
    status: {
        type: String,
        default:"Confirming your order",
        required: true,
    },
    deliveredAt: {
        type: Date,
        required: false
    },
    paymentMode: {
        type: String,
        required: true,
        trim: true
    },
    orderAmounts: {
        type: orderAmountSchema,
        required: true,
    },
    feedback: {
        type: feedback,
        required: false,
    },
    items: {
        type: Array,
        required: true
    },
    discountDetails: {
        type: discountAppliedDetailsSchema,
        required: false
    },
    specialInstruction: {
        type: String,
        required: false
    },
    orderedBy: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'Account'
    },
    address: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: "Address"
    },
    arrived: {
        type: Boolean,
        required: true,
        default: false
    },
    arrivedOn:{
        type: Date,
        required:false,
    }
}, {
    timestamps: true
})


const Order = mongoose.model('Order', orderSchema);

module.exports = Order;