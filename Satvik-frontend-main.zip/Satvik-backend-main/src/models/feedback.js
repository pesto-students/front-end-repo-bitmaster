const mongoose = require('mongoose');

const feedback = new mongoose.Schema({
    message:{
        type:String
    },
    rating:{
        type: Number,
        required:false
    }
},{ _id: false })

module.exports = feedback