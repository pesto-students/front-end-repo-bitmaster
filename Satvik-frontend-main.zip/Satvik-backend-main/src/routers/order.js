const express = require('express')
const Order = require('../models/order')
const router = new express.Router()
const auth = require('../middleware/auth.js')
const placeOrder = require('../service/placeOrder.js')

//create order
router.post('/placeOrder', auth, async (req, res) => {

    const order = {
        ...req.body,
        orderedBy: req.user._id
    }

    try {
        const response = await placeOrder(order);
        res.status(201).send(response)
    } catch (e) {
        res.status(400).send(e)
    }
});


router.get('/getOrder/:startFrom', auth, async (req, res) => {
    try {
        const startFrom = Number(req.params.startFrom);
        const orders = await Order.find({
            orderedBy: { $eq: req.user._id }
        }).sort({ createdAt: -1 })
            .skip(startFrom).limit(4)
            .populate('address', 'saveAs recieversName area houseNoAndFloor')
        res.status(201).send(orders);
    } catch (e) {
        console.log(e);
        res.status(400).send(e)
    }
});


router.get('/updateOrderStatus', async (req, res) => {
    try {
        const checkOrderExist = await Order.findOne({
            _id: { $eq: req.query.orderId }
        })
        if(checkOrderExist){
            const status = req.query.orderStatus;
            checkOrderExist.status=status;
            if(status==="delivered"){
                checkOrderExist.arrived=true,
                checkOrderExist.arrivedOn = new Date();
            }
            await checkOrderExist.save();
            res.status(200).json({ status: true });
        }
    } catch (error) {
        res.send(error)
    }
})
// router.post('/')

router.get('/orderStatus', auth, async (req, res) => {
    try {
        const orderId = req.query.orderId;
        res.setHeader('Content-Type', "text/event-stream");

        const sendOrderStatus = async () => {
            const orderStatus = await getOrderStatus(orderId, req.user._id);
            res.write(`data: ${orderStatus}\n\n`);
        };

        await sendOrderStatus();

        const intervalId = setInterval(sendOrderStatus, 5000);

        // Clean up when client closes connection
        req.on('close', () => {
            clearInterval(intervalId);
        });
    } catch (error) {
        console.error(error);
        res.status(500).end();
    }
});

async function getOrderStatus(orderId, userId) {
    const order = await Order.findOne({
        _id: orderId,
        orderedBy: userId
    }).select('status');
    return order ? order.status : 'Order not found';
}

router.post('/addFeedback', auth, async (req, res) => {
    try {
        const feedback = { ...req.body };
        const checkOrderExist = await Order.findOne({
            _id: { $eq: feedback.orderId }
        })
        if (checkOrderExist) {
            checkOrderExist.feedback = feedback;
            await checkOrderExist.save();
            res.status(200).json({ status: true })
        } else {
            res.status(400).send("feedback for this order already exist");
        }
    } catch (error) {
        res.status(400).send(error)
    }
})


// Read/list all order
router.get('/orders', auth, async (req, res) => {

    const match = {};
    const sort = {};

    if (req?.query?.completed) {
        match.completed = req.query.completed === 'true';
        console.log(match)
    }

    if (req?.query?.sortBy) {
        const parts = req.query.sortBy.split(':')
        sort[parts[0]] = parts[1] === 'desc' ? -1 : 1;
    }

    try {
        const user = req.user;
        await user.populate({
            path: 'orders',
            match,
            options: {
                limit: parseInt(req.query.limit),
                skip: parseInt(req.query.skip),
                sort
            }
        }).execPopulate();
        console.log(user.orders)
        res.send(user.orders)
    } catch (e) {
        console.log('risi - error', e)
        res.status(500).send()
    }
})


// Read/list a particular order
router.get('/orders/:id', auth, async (req, res) => {
    const _id = req.params.id

    try {
        const order = await Order.findOne({ _id, owner: req.user._id })

        if (!order) {
            return res.status(404).send()
        }

        res.send(order)
    } catch (e) {
        res.status(500).send()
    }
})

// Update an by ID - for feedback / completed
router.patch('/orders/:id', auth, async (req, res) => {
    const updates = Object.keys(req.body)
    const allowedUpdates = ['completed', 'feedback']
    const isValidOperation = updates.every((update) => allowedUpdates.includes(update))

    if (!isValidOperation) {
        return res.status(400).send({ error: 'Invalid updates!' })
    }

    try {
        const order = await Order.findOne({ _id: req.params.id, owner: req.user._id });

        if (!order) {
            return res.status(404).send()
        }

        updates.forEach(update => order[update] = req.body[update]);
        await order.save();

        res.send(order)
    } catch (e) {
        res.status(400).send(e)
    }
})


module.exports = router