const express = require('express')
const router = new express.Router()
const review = require("../models/Review");

router.get('/reviews/:startFrom', async (req, res) => {
    try {
        const startFrom = Number(req.params.startFrom);
        const reviews = await review.find().sort({ createdAt: -1 }).skip(startFrom).limit(4);
        res.status(201).send(reviews);
    } catch (e) {
        res.status(400).send(e)
    }
});


router.get('/savefeedback', async (req, res) => {
    try {
        const feedBack = new review({
            author: "Emily",
            message: "Bursting with vibrant colors and robust flavors, the Mediterranean salad was a refreshing delight. Crisp lettuce, juicy tomatoes, and briny olives were tossed in a zesty vinaigrette, creating a harmonious medley of tastes and textures. A healthy and satisfying meal that left me feeling nourished and energized.",
            rating: Math.floor(Math.random() * 5) + 1,
        })
        const reviews = await feedBack.save();
        res.status(201).send(reviews);
    } catch (e) {
        res.status(400).send(e)
    }
});

module.exports = router