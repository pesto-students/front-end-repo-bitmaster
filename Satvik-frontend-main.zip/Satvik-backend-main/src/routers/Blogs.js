const express = require('express')
const router = new express.Router()
const Blog = require('../models/Blog');


router.get("/saveBlog", async (req, res) => {
    try {
        const blogDetails = new Blog({
            blogTitle: "Best products for fitness nutrition and muscles",
            blogShortDescription: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis incidunt quia labore quisquam provident reiciendis. Illum numquam tempora deserunt, est dignissimos pariatur ipsa alias delectus quaerat optio ut sint a?",
            blogImageUrl: "hello",
            writtenBy: "Yukti",
            blogData: {
                "Fitness news, articles and information": [
                    "Lorem, ipsum dolor sit amet consectetur adipisicing elit. At quisquam enim ab, in perferendis iste sed laborum dolorum neque culpa praesentium, earum ducimus nesciunt, non animi omnis veniam nam id! Alias est provident non consequatur nisi ullam reprehenderit quasi eveniet quae id. Aliquid nam expedita quia consequuntur eum sit eligendi dignissimos, reprehenderit incidunt natus, aut, corporis laborum suscipit obcaecati harum. Atque voluptas tempora totam, sed sint nostrum aspernatur veniam nihil tenetur voluptate quod! Odio neque iure architecto vitae cum quos molestias asperiores, repellat aut, omnis sit reiciendis, distinctio corporis assumenda. Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt, labore perferendis? Dolor similique aliquid debitis recusandae. Repudiandae culpa velit itaque. Dolor assumenda, amet eum incidunt sint animi ullam quas qui. Necessitatibus doloribus quis inventore commodi corrupti nulla consectetur ipsam dolores illum ea iste nam, et recusandae nobis dolorem nesciunt reiciendis impedit ut amet in fugiat veritatis hic quisquam. Facilis, autem? Impedit facere fugit rem eos dolore! Sint autem consequatur hic obcaecati, quibusdam exercitationem sapiente? Iusto natus quaerat iste odit adipisci doloremque deserunt! Saepe voluptas suscipit repellendus nesciunt excepturi corporis sunt.",
                    "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Dignissimos debitis, ut praesentium assumenda nobis repellendus vel nam sit impedit unde fuga vero possimus perferendis at iusto aut ab. Quis, reprehenderit! Eos laudantium aspernatur debitis iste accusamus cum a doloribus quasi iure, ipsum neque ratione laborum dolor accusantium, esse eius, quibusdam eaque quisquam facere optio. Placeat, veritatis. Quod nisi cupiditate temporibus? Deserunt eveniet adipisci maxime debitis modi dolorem quo quis est iure exercitationem, provident ab consequatur. A labore quia, veniam voluptatum assumenda illo praesentium pariatur aut laboriosam libero? Fuga, iure officia. Ea velit eos voluptate eum, impedit est exercitationem tempore perspiciatis blanditiis? Corporis, quasi. Eligendi eius molestias recusandae expedita, delectus atque, id inventore laboriosam sequi aspernatur accusamus fugit incidunt sint. Soluta? Velit, placeat assumenda distinctio perferendis facere eaque nam aspernatur ratione! Quasi enim reprehenderit, facilis unde, corrupti ad accusamus asperiores voluptatem reiciendis sequi voluptas exercitationem aut labore non inventore, numquam cupiditate."
                ],
                "Health and Fitness": [
                    "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Possimus excepturi est voluptatibus eaque molestias unde voluptatem, distinctio delectus quisquam, pariatur voluptate animi neque? Corporis distinctio ad nesciunt amet? Aliquam, provident! Unde aspernatur iste dignissimos, ratione sequi consequuntur qui odit sunt obcaecati, temporibus provident cupiditate nam vel non. Est sint id illum doloremque exercitationem ea blanditiis, eligendi maxime voluptatem nam itaque. Dolore repudiandae ea aut labore! Asperiores ratione id accusamus cupiditate! Necessitatibus quam est, iste recusandae optio quisquam veritatis natus assumenda quis delectus magnam explicabo earum placeat eius blanditiis ullam sequi. Asperiores necessitatibus et provident rem. Explicabo nemo veniam blanditiis minima illum, ipsum consectetur dolores possimus et culpa ipsam similique atque quos officia cum fugiat laborum, non ad a itaque impedit"
                ]
            }
        })

        blogDetails.save();
        res.status(200).send("saved");
    } catch (error) {

    }
});



router.get("/getBlogs", async (req, res) => {
    try {
        const blogs = await Blog.find({}, 'blogTitle blogShortDescription blogImageUrl updatedAt').sort({ createdAt: -1 }).limit(3)
        res.status(200).json(blogs);
    } catch (error) {
        res.status(400).send(error)
    }
});


router.get("/getBlog/:id", async (req, res) => {
    try {
        const id = req.params.id;
        const blog = await Blog.findOne({_id:id})
        res.status(200).json(blog);
    } catch (error) {
        res.status(400).send(error)
    }
});



module.exports = router