const express = require('express')
const router = new express.Router()
const team = require("../models/Team.js");

router.get('/ourTeam', async (req, res) => {
    try {
        const teamDetails = await team.find();
        res.status(201).send(teamDetails);
    } catch (e) {
        res.status(400).send(e)
    }
})

module.exports = router