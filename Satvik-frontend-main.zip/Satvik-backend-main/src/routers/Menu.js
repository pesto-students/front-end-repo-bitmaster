const express = require('express')
const User = require('../models/user.js')
const router = new express.Router()
const auth = require('../middleware/auth.js')
const Food = require('../models/food.js')
const Menu = require('../models/Menu.js')

//create order
router.post('/item', async (req, res) => {
    const food = new Food({
        ...req.body
    })

    try {
        await food.save()
        res.status(201).send(food)
    } catch (e) {
        res.status(400).send(e)
    }
});

// router.get('/saveItems', async (req, res) => {

//     let a = [];

//     for (let i = 1; i < 5; i++) {
//         const item = new Menu({
//             itemName: `Sample Drink ${i}`,
//             itemDescription: "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Error voluptas officiis, similique distinctio",
//             itemPrice: Math.floor(Math.random() * (250 - 150 + 1)) + 150,
//             itemType: "veg",
//             isAvailable: true,
//             itemImageUrl: "",
//             emotion: "",
//             menuItemType: "drink",
//             totalOrders: Math.floor(Math.random() * (32 - 10 + 1)) + 10
//         })
//         a.push(item)
//     }

//     try {
//         Menu.insertMany(a);
//         res.status(201).send("saved")
//     } catch (e) {
//         res.status(400).send(e)
//     }
// });



router.get('/Menu/:menuItemType?', async (req, res) => {
    try {
        const menuItemType = req.params.menuItemType;
        let allItems = null;
        if (menuItemType && menuItemType !== "all") {
            allItems = await Menu.find({ menuItemType });
        } else if (menuItemType === "all") {
            allItems = await Menu.find();
        }
        res.status(200).send(allItems);
    } catch (e) {
        res.status(400).send(e)
    }
})


router.get('/popularDishes', async (req, res) => {
    try {
        const popularItems = await Menu.find().sort({ totalOrders: -1 }).limit(4);
        res.send(popularItems);
    } catch (e) {
        res.send(e)
    }
})



router.post('/getItemDetailsById', async (req, res) => {
    try {
        const dataArray = req.body;
        const itemIds = [...dataArray].map((item) => item.itemId);
        const items = await Menu.find({ _id: { $in: itemIds } });
        let totalPriceBeforeTax = 0;
        const response = [];
        items.forEach((item) => {
            dataArray.forEach(everyItem => {
                if (item._id == everyItem.itemId) {
                    const itemDetails = { ...item._doc, quantityAddedToCart: everyItem.quantity };
                    totalPriceBeforeTax += item.itemPrice * everyItem.quantity;
                    response.push(itemDetails)
                }
            })
        });
        let totalTax = (totalPriceBeforeTax * 0.05).toFixed(2);
        let totalPriceAfterTax = Number(totalPriceBeforeTax) + Number(totalTax);
        res.status(201).json({ items: response, totalPriceBeforeTax, totalTax, totalPriceAfterTax });
    } catch (e) {
        res.status(400).send(e)
    }
})

// Read/list a particular food
router.get('/foods/:id', async (req, res) => {
    const _id = req.params.id

    try {
        const food = await Food.findOne({ _id })

        if (!food) {
            return res.status(404).send()
        }

        res.send(food)
    } catch (e) {
        res.status(500).send()
    }
});

// Update an by ID - 
router.patch('/foods/:id', auth, async (req, res) => {
    const updates = Object.keys(req.body)
    try {
        const food = await Food.findOne({ _id: req.params.id });

        if (!food) {
            return res.status(404).send()
        }

        updates.forEach(update => food[update] = req.body[update]);
        await food.save();

        res.send(food)
    } catch (e) {
        res.status(400).send(e)
    }
})


// delete an by ID - 
router.delete('/foods/:id', auth, async (req, res) => {
    try {
        const food = await Food.findOneAndDelete({ _id: req.params.id })

        if (!food) {
            res.status(404).send()
        }

        res.send(food)
    } catch (e) {
        res.status(500).send()
    }
})




module.exports = router