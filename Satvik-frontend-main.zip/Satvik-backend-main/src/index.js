// const Sentry = require("@sentry/node");
// const { ProfilingIntegration } = require("@sentry/profiling-node");
const cors = require('cors');
const express = require('express')
const bodyParser = require('body-parser')

require('dotenv').config(); 
require('./db/mongoose');



const userRouter = require('./routers/user')
const orderRouter = require('./routers/order')
const foodRouter = require('./routers/Menu')
const teamRouter = require('./routers/TeamDetails')
const reviews = require('./routers/Reviews')
const accountRouter = require('./routers/Account')
const discountRouter = require('./routers/Discount')
const blogRouter = require('./routers/Blogs')
const addressRouter = require('./routers/Address')
const franchiseQueryRouter =  require('./routers/FranchiseQuery')

const app = express()
app.use(cors({ credentials: true, origin: ["http://localhost:3000","http://192.168.0.109:3000"] }))
app.use(bodyParser.urlencoded({extended:true}))
const port = process.env.PORT || 3000
app.use(express.json())
app.use(userRouter)
app.use(orderRouter)
app.use(teamRouter)
app.use(foodRouter)
app.use(reviews)
app.use(accountRouter);
app.use(discountRouter);
app.use(blogRouter);
app.use(addressRouter);
app.use(franchiseQueryRouter)

app.listen(port, () => {
    console.log('Server is up on port ' + port)
})