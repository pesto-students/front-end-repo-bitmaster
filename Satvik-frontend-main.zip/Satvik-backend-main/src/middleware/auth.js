const Account = require('../models/Account');
const jwt = require('jsonwebtoken');

const auth = async (req, res, next) => {
    try {
        let token;
        if(req.header('Authorization')){
            token = req.header('Authorization').replace('Bearer ', '');
        }else{
            token = req.query.Authorization.replace('Bearer ', '');
        }
        
        const payload = jwt.verify(token, process.env.MY_SECRET);
        const expiration = payload?.exp;
        let now = Date.now() / 1000;
        
        if(expiration < now) {
            throw new Error('Session Expired, relogin...')
        }
        
        const user = await Account.findOne({ _id: payload?.data?._id});

        if (!user) {
            throw new Error('User not found')
        }

        req.user = user;
        req.token = token;
        next();
    }
    catch (error) {
        console.log(error);
        if(error.name === 'TokenExpiredError'){
            return res.status(401).json({message:'Your Session has expired! Please login again'})
        }else if(error.name === 'JsonWebTokenError'){
            return res.status(401).json({message:'You need to be logged in'})
        }
        return res.status(400).send(error)
    }
}

module.exports = auth;